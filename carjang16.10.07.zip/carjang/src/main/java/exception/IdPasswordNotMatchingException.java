package exception;

public class IdPasswordNotMatchingException 
	extends RuntimeException{
}
