package exception;

public class MemberNotFoundException 
extends RuntimeException{
	
}
