package board;

import java.util.Date;

public class BoardSearch {

	private String board_loc;
	private String board_date1;
	private String board_date2;
	private String board_time1;
	private String board_time2;
	private int board_price1;
	private int board_price2;

	public String getBoard_loc() {
		return board_loc;
	}

	public void setBoard_loc(String board_loc) {
		this.board_loc = board_loc;
	}

	public String getBoard_date1() {
		return board_date1;
	}

	public void setBoard_date1(String board_date1) {
		this.board_date1 = board_date1;
	}

	public String getBoard_date2() {
		return board_date2;
	}

	public void setBoard_date2(String board_date2) {
		this.board_date2 = board_date2;
	}

	public String getBoard_time1() {
		return board_time1;
	}

	public void setBoard_time1(String board_time1) {
		this.board_time1 = board_time1;
	}

	public String getBoard_time2() {
		return board_time2;
	}

	public void setBoard_time2(String board_time2) {
		this.board_time2 = board_time2;
	}

	public int getBoard_price1() {
		return board_price1;
	}

	public void setBoard_price1(int board_price1) {
		this.board_price1 = board_price1;
	}

	public int getBoard_price2() {
		return board_price2;
	}

	public void setBoard_price2(int board_price2) {
		this.board_price2 = board_price2;
	}

}