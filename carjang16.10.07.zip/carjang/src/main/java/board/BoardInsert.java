package board;

import java.util.Date;

public class BoardInsert {

	private String board_drvId;
	private int board_price;
	private String board_date1;
	private String board_date2;
	private String board_time1;
	private String board_time2;
	private String board_loc;
	private int board_limit;
	private int board_pickup;
	private String board_comment;
	private String board_car;
	


	public String getBoard_car() {
		return board_car;
	}

	public void setBoard_car(String board_car) {
		this.board_car = board_car;
	}

	public String getBoard_drvId() {
		return board_drvId;
	}

	public void setBoard_drvId(String board_drvId) {
		this.board_drvId = board_drvId;
	}

	public int getBoard_price() {
		return board_price;
	}

	public void setBoard_price(int board_price) {
		this.board_price = board_price;
	}

	public String getBoard_loc() {
		return board_loc;
	}

	public void setBoard_loc(String board_loc) {
		this.board_loc = board_loc;
	}

	public int getBoard_limit() {
		return board_limit;
	}

	public void setBoard_limit(int board_limit) {
		this.board_limit = board_limit;
	}

	public int getBoard_pickup() {
		return board_pickup;
	}

	public void setBoard_pickup(int board_pickup) {
		this.board_pickup = board_pickup;
	}

	public String getBoard_comment() {
		return board_comment;
	}

	public void setBoard_comment(String board_comment) {
		this.board_comment = board_comment;
	}

	public String getBoard_date1() {
		return board_date1;
	}

	public void setBoard_date1(String board_date1) {
		this.board_date1 = board_date1;
	}

	public String getBoard_date2() {
		return board_date2;
	}

	public void setBoard_date2(String board_date2) {
		this.board_date2 = board_date2;
	}

	public String getBoard_time1() {
		return board_time1;
	}

	public void setBoard_time1(String board_time1) {
		this.board_time1 = board_time1;
	}

	public String getBoard_time2() {
		return board_time2;
	}

	public void setBoard_time2(String board_time2) {
		this.board_time2 = board_time2;
	}
	
	

}